﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
using System;
using IPCA.MonoGame;
using System.Collections.Generic;

namespace pigeonMiner
{
    public class Game1 : Game
    {
        private struct bombs
        {
            public bool bombE;
            public Point bombP;
            public double bombT, EndBomb;
        }

        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Player Pombo;
        private SpriteFont arial24;

        private string[] levelNames = { "2level.txt" , "3level.txt" };//, "level1.txt" };
        private int currentLevel = 0, ERadious = 1, cd;
        private double levelTime = 0f;
        private bool rDown = false, isWin = false, aux = true, Life=true;

        private Vector2 limits;

        

        private List<bombs> bombas;

        public const int tileSize = 32;
        public char[,] level;
        public List<Point> stones, diamonds, dynamites;
        public List<bool> Mstones;
        public int TotalDiamonds = 0;

        private SpriteSheet _sheet;
        private Texture2D StartMenu,RipMenu,WinMenu;


        private List<Component> _startGameComponents;
        private List<Component> _loseGameComponents;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            new KeyboardManager(this);
   
            KeyboardManager.Register(Keys.Escape, KeysState.GoingDown, Exit);
            KeyboardManager.Register(Keys.E, KeysState.GoingDown, explusioun);
        }

        protected override void Initialize()
        {
            LoadLevel(levelNames[currentLevel]);
            _graphics.PreferredBackBufferHeight = tileSize * (level.GetLength(1)+1);
            _graphics.PreferredBackBufferWidth = tileSize * level.GetLength(0);
            _graphics.ApplyChanges();
            
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _sheet = new SpriteSheet(this, "PigeonMiner");
            arial24 = Content.Load<SpriteFont>("arial24");

            StartMenu = Content.Load<Texture2D>("StartMenu1");
            RipMenu = Content.Load<Texture2D>("RipMenu");
            WinMenu = Content.Load<Texture2D>("WinMenu");

            #region Menu
            Vector2 windowSize = new Vector2(_graphics.PreferredBackBufferWidth,
                        _graphics.PreferredBackBufferHeight);
            Vector2 windowCenter = windowSize / 2f;


            var PlayButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Fonts/Font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "Play",
            };

            PlayButton.Click += Play;

            var PlayAgainButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Fonts/Font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "Play Again",
            };

            PlayButton.Click += PlayAgain;


            var quitButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Fonts/Font"))
            {

                Position = new Vector2(windowCenter.X-64, windowCenter.Y+8),
                Text = "Quit",
            };

            quitButton.Click += QuitButton_Click;

            _startGameComponents = new List<Component>() { PlayButton, quitButton, };
            _loseGameComponents = new List<Component>() { PlayAgainButton, quitButton, };
            #endregion


        }

        protected override void Update(GameTime gameTime)
        {
            if (!isWin) levelTime += gameTime.ElapsedGameTime.TotalSeconds;

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (!rDown && Keyboard.GetState().IsKeyDown(Keys.R))
            {
                rDown = true;
                
                if (isWin)
                {
                    currentLevel = 0;
                    levelTime = 0f;
                    
                    isWin = false;
                }
                Initialize();

            }
            else if (Keyboard.GetState().IsKeyUp(Keys.R))
            {
                rDown = false;
            }


            if (Victory())
            {
                if (currentLevel < levelNames.Length - 1)
                {
                    currentLevel++;
                    Initialize();
                }
                else
                {
                    isWin = true;
                }
            }

            if (!isWin) Pombo.Update(gameTime);

            if (cd > 16) { gravity(); cd = 0; } else { cd++; }

            if (bombas.Count > 0)
            {
                for(int i = 0; i < bombas.Count; i++)
                {
                    if (bombas[i].EndBomb!=0 && bombas[i].EndBomb < levelTime)
                    {
                        addRemoveFire(false, bombas[i].bombP);
                        bombas.Remove(bombas[i]);
                    }       
                    else
                    {
                        if (bombas[i].bombE)
                        {
                            var val = bombas[i];
                            val.bombE = false;
                            bombas[i] = val;
                        }
                        else
                        {
                            if (bombas[i].bombT < levelTime)
                            {
                                BOOOMMM(bombas[i].bombP.X, bombas[i].bombP.Y);
                                addRemoveFire(true, bombas[i].bombP);
                                var val = bombas[i];
                                val.bombE = false;
                                val.EndBomb = 1f + levelTime;
                                val.bombT = 5f + levelTime;
                                bombas[i] = val;
                            }
                        }
                    } 
                }
            }

            foreach (var component in _startGameComponents)
                component.Update(gameTime);

            foreach (var component in _loseGameComponents)
                component.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            _spriteBatch.Begin();

            //_spriteBatch.Draw(background, new Vector2(0, 0), Color.White);
            
            if (aux)
            {
                _spriteBatch.Draw(StartMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                foreach (var component in _startGameComponents)
                    component.Draw(gameTime, _spriteBatch);
            }
            else
            {
                if (isWin)
                {
                    _spriteBatch.Draw(WinMenu, GraphicsDevice.Viewport.Bounds, Color.White);

                    Vector2 windowSize = new Vector2(_graphics.PreferredBackBufferWidth,
                          _graphics.PreferredBackBufferHeight);
                    string win = $"    You mined {TotalDiamonds} diamonds\nand took {levelTime:f1} seconds to win!!!";
                    Vector2 winMeasures = arial24.MeasureString(win) / 2f;
                    Vector2 windowCenter = windowSize / 2f;
                    _spriteBatch.DrawString(arial24, win, windowCenter - winMeasures, Color.Black);


                }
                else
                {
                    if (Life)
                    {

                        //Color.SaddleBrown
                        GraphicsDevice.Clear(new Color(123, 86, 50));
                        Rectangle position = new Rectangle(0, 0, tileSize, tileSize);

                        for (int x = 0; x < level.GetLength(0); x++)
                        {
                            for (int y = 0; y < level.GetLength(1); y++)
                            {
                                position.X = x * tileSize;
                                position.Y = y * tileSize;

                                switch (level[x, y])
                                {
                                    case 'Z': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["WallRound_Gray.png"], Color.DarkGray); break;
                                    case 'X': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Wall_Black.png"], Color.White); break;
                                    case 'T': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Dirt.png"], Color.White); break;
                                    case 'E': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Bomb.png"], Color.White); break;
                                    case 'D': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Diamond.png"], Color.White); break;
                                    case 'S': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Door.png"], Color.White); break;
                                    case 'O': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Rock.png"], Color.White); break;
                                    case 'F': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Bomb.png"], Color.MediumVioletRed); break;
                                    case 'I': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Explosion.png"], Color.White); break;
                                }
                            }
                        }

                        Pombo.Draw(_spriteBatch, _sheet);


                      
                        _spriteBatch.DrawString(arial24,
                            string.Format("Diamonds: {0}     Dynamites: {1}     Dirt: {2}",
                                            Pombo.diamonds, Pombo.dinamites, Pombo.dirt),
                                new Vector2(5, level.GetLength(1) * tileSize),
                                Color.Black, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0);

                        string lifes = string.Format("Time: {0:F0}", levelTime);
                        Point measure = arial24.MeasureString(lifes).ToPoint();
                        int posX = level.GetLength(0) * tileSize - measure.X - 5;

                        _spriteBatch.DrawString(arial24, lifes,
                            new Vector2(posX, level.GetLength(1) * tileSize), Color.Black
                            , 0f, Vector2.Zero, 1f, SpriteEffects.None, 0);
                    }


                    else
                    {
                        _spriteBatch.Draw(RipMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                        GraphicsDevice.Clear(Color.Aquamarine);
                        foreach (var component in _loseGameComponents)
                            component.Draw(gameTime, _spriteBatch);
                    }

                }
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }

        public bool Victory()
        {
            if (level[Pombo.getP().X, Pombo.getP().Y] == 'S')
                return true; return false;
        }

        public char Tile(int x, int y)
        {
            return level[x, y];
        }

        public void destroyTile(int x, int y)
        {
            Point p = new Point(x, y);
            if(x>0&& x < limits.Y && y > 0 && y < limits.X)
            {
                if (level[x, y] == 'D') diamonds.Remove(p);

                if (level[x, y] == 'E') dynamites.Remove(p);

                if (level[x, y] == 'O')
                {
                    for(int i = 0; i < stones.Count; i++)
                    {
                        if (stones[i] == p)
                        {
                            Mstones.RemoveAt(i); 
                        }
                    }
                    stones.Remove(p);
                } 

                if (!(level[x, y] == 'X' || level[x, y] == 'S')) level[x, y] = ' ';
            }
        }

        public void addRemoveFire(bool fire,Point pt)
        {
            if (fire)
            {
                for (int i = pt.X - ERadious; i <= pt.X + ERadious; i++)
                {
                    for (int u = pt.Y + ERadious; u >= pt.Y - ERadious; u--)
                    {
                        if (!(level[i, u] == 'X' || level[i, u] == 'S')) level[i, u] = 'I';
                    }
                }

            }
            else
            {
                for (int i = pt.X - ERadious; i <= pt.X + ERadious; i++)
                {
                    for (int u = pt.Y + ERadious; u >= pt.Y - ERadious; u--)
                    {
                        if (!(level[i, u] == 'X' || level[i, u] == 'S')) level[i, u] = ' ';
                    }
                }
            }
            
        }

        public void gravity()
        {
            for (int i = 0; i < dynamites.Count; i++)
            {
                if (level[dynamites[i].X, dynamites[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(dynamites[i].X, dynamites[i].Y + 1)))
                {
                    if (level[dynamites[i].X, dynamites[i].Y + 2] == ' ' && !Pombo.pPlayer(new Point(dynamites[i].X, dynamites[i].Y + 1)))
                    {
                        level[dynamites[i].X, dynamites[i].Y] = ' ';
                        level[dynamites[i].X, dynamites[i].Y + 1] = 'E';
                        dynamites[i] = new Point(dynamites[i].X, dynamites[i].Y + 1);
                    }
                    else
                    {
                        level[dynamites[i].X, dynamites[i].Y] = ' ';
                        int x = dynamites[i].X; int y = dynamites[i].Y;
                        dynamites.Remove(new Point(dynamites[i].X, dynamites[i].Y));
                        bombas.Add(new bombs() { bombE = true, bombP = new Point(x, y + 1), bombT = levelTime, EndBomb = 0 });
                    }
                }
            }


            for (int i = 0; i < stones.Count; i++)
            {
                if (Mstones[i])
                {
                    if (Pombo.pPlayer(new Point(stones[i].X, stones[i].Y + 1)))
                    {
                        Life = false;
                    }

                    if (level[stones[i].X, stones[i].Y + 1] == ' ')
                    {
                        level[stones[i].X, stones[i].Y] = ' ';
                        level[stones[i].X, stones[i].Y + 1] = 'O';
                        stones[i] = new Point(stones[i].X, stones[i].Y + 1);
                        Mstones[i] = true;
                    }
                    else
                    {
                        if (level[stones[i].X, stones[i].Y + 1] == 'E')
                        {
                            level[stones[i].X, stones[i].Y + 1] = ' ';
                            int x = stones[i].X; int y = stones[i].Y + 1;
                            dynamites.Remove(new Point(stones[i].X, stones[i].Y+1));
                            bombas.Add(new bombs() { bombE = true, bombP = new Point(x, y), bombT = levelTime , EndBomb = 0 });
                        }

                        else
                        {
                            Mstones[i] = false;
                        }
                    }
                }



                if (!Mstones[i])
                {
                    if (level[stones[i].X, stones[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(stones[i].X, stones[i].Y + 1)))
                    {
                        level[stones[i].X, stones[i].Y] = ' ';
                        level[stones[i].X, stones[i].Y + 1] = 'O';
                        stones[i] = new Point(stones[i].X, stones[i].Y + 1);
                        Mstones[i] = true;
                    }
                    else
                    {
                        if (level[stones[i].X, stones[i].Y + 1] == 'O' || level[stones[i].X, stones[i].Y + 1] == 'D')
                        {
                            if (level[stones[i].X - 1, stones[i].Y] == ' ' && !Pombo.pPlayer(new Point(stones[i].X - 1, stones[i].Y)) &&
                                level[stones[i].X - 1, stones[i].Y + 1] == ' ')
                            {
                                level[stones[i].X, stones[i].Y] = ' ';
                                level[stones[i].X - 1, stones[i].Y] = 'O';
                                stones[i] = new Point(stones[i].X - 1, stones[i].Y);
                                Mstones[i] = true;

                            }
                            else
                            {
                                if (level[stones[i].X + 1, stones[i].Y] == ' ' && !Pombo.pPlayer(new Point(stones[i].X - 1, stones[i].Y)) &&
                                level[stones[i].X + 1, stones[i].Y + 1] == ' ')
                                {
                                    level[stones[i].X, stones[i].Y] = ' ';
                                    level[stones[i].X + 1, stones[i].Y] = 'O';
                                    stones[i] = new Point(stones[i].X + 1, stones[i].Y);
                                    Mstones[i] = true;
                                }
                            }
                        }
                    }
                }
                
                
            }

            for (int i = 0; i < diamonds.Count; i++)
            {
                if (level[diamonds[i].X, diamonds[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X, diamonds[i].Y + 1)))
                {
                    level[diamonds[i].X, diamonds[i].Y] = ' ';
                    level[diamonds[i].X, diamonds[i].Y + 1] = 'D';
                    diamonds[i] = new Point(diamonds[i].X, diamonds[i].Y + 1);
                }
                else
                {
                    if (level[diamonds[i].X, diamonds[i].Y + 1] == 'O' || level[diamonds[i].X, diamonds[i].Y + 1] == 'D')
                    {
                        if (level[diamonds[i].X - 1, diamonds[i].Y] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X - 1, diamonds[i].Y)) &&
                            level[diamonds[i].X - 1, diamonds[i].Y + 1] == ' ')
                        {
                            level[diamonds[i].X, diamonds[i].Y] = ' ';
                            level[diamonds[i].X - 1, diamonds[i].Y] = 'D';
                            diamonds[i] = new Point(diamonds[i].X - 1, diamonds[i].Y);
                        }
                        else
                        {
                            if (level[diamonds[i].X + 1, diamonds[i].Y] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X - 1, diamonds[i].Y)) &&
                            level[diamonds[i].X + 1, diamonds[i].Y + 1] == ' ')
                            {
                                level[diamonds[i].X, diamonds[i].Y] = ' ';
                                level[diamonds[i].X + 1, diamonds[i].Y] = 'D';
                                diamonds[i] = new Point(diamonds[i].X + 1, diamonds[i].Y);
                            }
                        }
                    }
                }
            }

           
        }

        public void explusioun()
        {
            if (Pombo.dinamites > 0)
            {
                Point pt = Pombo.getP();
                level[pt.X, pt.Y] = 'F';
                bombas.Add(new bombs() {bombE=true,bombP= pt, bombT=levelTime+2f,EndBomb=0 });
                Pombo.dinamites--;
            }
        }

        public void BOOOMMM(int x,int y)
        {
            for(int i = x - ERadious; i <= x + ERadious; i++)
            {
                for(int u = y + ERadious; u >= y - ERadious; u--)
                {
                    if (Pombo.getP().X == i && Pombo.getP().Y == u)
                        Life = false;
                    destroyTile(i, u);
                }
            }
            
            Console.WriteLine("CABOOOMMMM!!!!");
        }
  
        void LoadLevel(string levelFile)
        {
            bombas = new List<bombs>();
            Mstones = new List<bool>();
            stones = new List<Point>();
            diamonds = new List<Point>();
            dynamites = new List<Point>();

            string[] linhas = File.ReadAllLines("Content/" + levelFile);
            int nrLinhas = linhas.Length; int nrColunas = linhas[0].Length;
            limits = new Vector2(nrLinhas, nrColunas);

            level = new char[nrColunas, nrLinhas];

            for (int x = 0; x < nrColunas; x++)
            {
                for (int y = 0; y < nrLinhas; y++)
                {
                    switch (linhas[y][x])
                    {
                        case 'Y': Pombo = new Player(this, x, y); level[x, y] = ' '; break;
                        case 'O': Mstones.Add(false); stones.Add(new Point(x, y)); level[x, y] = 'O'; break;
                        case 'D': diamonds.Add(new Point(x, y)); level[x, y] = 'D'; break;
                        case 'E': dynamites.Add(new Point(x, y)); level[x, y] = 'E'; break;
                        default: level[x, y] = linhas[y][x]; break;
                    }
                }
            }
        }

        private void QuitButton_Click(object sender, System.EventArgs e)
        {
            Exit();
        }

        private void Play(object sender, System.EventArgs e)
        {
            aux = false;
        }

        private void PlayAgain(object sender, System.EventArgs e)
        {
            Life = true;
            currentLevel = 0;
            levelTime = 0;
            TotalDiamonds = 0;
            Initialize();
        }
    }
}