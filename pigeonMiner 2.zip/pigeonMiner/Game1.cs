﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
using System;
using IPCA.MonoGame;
using System.Collections.Generic;

namespace pigeonMiner
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Player Pombo;
        private SpriteFont arial24;

        private string[] levelNames = { "2level.txt" , "2level.txt" };//, "level1.txt" };
        private int currentLevel = 0, ERadious = 1, lifeCount = 3, cd;
        private double levelTime = 0f;
        private bool rDown = false, isWin = false;

        private Vector2 limits;

        private List<bool> bombas;
        private List<Point> bombasP;
        private List<double> bombasT;

        public const int tileSize = 32;
        public char[,] level;
        public List<Point> stones, diamonds, dynamites;

        private SpriteSheet _sheet;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            new KeyboardManager(this);
   
            KeyboardManager.Register(Keys.Escape, KeysState.GoingDown, Exit);
            KeyboardManager.Register(Keys.E, KeysState.GoingDown, explusioun);
        }

        protected override void Initialize()
        {
            LoadLevel(levelNames[currentLevel]);
            _graphics.PreferredBackBufferHeight = tileSize * (level.GetLength(1)+1);
            _graphics.PreferredBackBufferWidth = tileSize * level.GetLength(0);
            _graphics.ApplyChanges();

            base.Initialize();
        }


        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _sheet = new SpriteSheet(this, "TextureDiamondMiner");
            arial24 = Content.Load<SpriteFont>("arial24");
        }

        protected override void Update(GameTime gameTime)
        {
            if (!isWin) levelTime += gameTime.ElapsedGameTime.TotalSeconds;

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (!rDown && Keyboard.GetState().IsKeyDown(Keys.R))
            {
                rDown = true;
                lifeCount--;
                if (isWin || lifeCount < 0)
                {
                    currentLevel = 0;
                    levelTime = 0f;
                    lifeCount = 3;
                    isWin = false;
                }
                Initialize();

            }
            else if (Keyboard.GetState().IsKeyUp(Keys.R))
            {
                rDown = false;
            }


            if (Victory())
            {
                if (currentLevel < levelNames.Length - 1)
                {
                    currentLevel++;
                    Initialize();
                }
                else
                {
                    isWin = true;
                }
            }

            if (!isWin) Pombo.Update(gameTime);

            if (cd > 16) { gravity(); cd = 0; } else { cd++; }

            if (bombas.Count > 0)
            {
                for(int i = 0; i < bombas.Count; i++)
                {
                    if (bombas[i])
                    {
                        bombas[i] = false;
                        bombasT.Add(levelTime + 2f);
                    }
                    else
                    {
                        if (bombasT[i] < levelTime)
                        {
                            BOOOMMM(bombasP[i].X,bombasP[i].Y);
                            bombas.Remove(bombas[i]);
                            bombasP.Remove(bombasP[i]);
                            bombasT.Remove(bombasT[i]);
                        }
                    }
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.BurlyWood);

            _spriteBatch.Begin();

            Rectangle position = new Rectangle(0, 0, tileSize, tileSize);

            for (int x = 0; x < level.GetLength(0); x++)
            {
                for (int y = 0; y < level.GetLength(1); y++)
                {
                    position.X = x * tileSize;
                    position.Y = y * tileSize;

                    switch (level[x, y])
                    {
                        case 'X': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Wall_Black.png"], Color.White); break;
                        case 'T': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Dirt.png"], Color.White); break;
                        case 'E': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["bomb.png"], Color.White); break;
                        case 'D': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Diamond.png"], Color.White); break;
                        case 'S': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Door.png"], Color.White); break;
                        case 'O': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["Pedra.png"], Color.White); break;
                        case 'F': _spriteBatch.Draw(_sheet.Sheet, position, _sheet["bomb.png"], Color.MediumVioletRed); break;
                    }
                }
            }

            Pombo.Draw(_spriteBatch, _sheet);

            if (isWin)
            {
                Vector2 windowSize = new Vector2(_graphics.PreferredBackBufferWidth,
                    _graphics.PreferredBackBufferHeight);

                Texture2D pixel = new Texture2D(GraphicsDevice, 1, 1);
                    pixel.SetData(new[] { Color.White });
                
                _spriteBatch.Draw(pixel, new Rectangle(Point.Zero, windowSize.ToPoint()),
                    new Color(Color.BlueViolet, 0.5f));

                string win = $"You took {levelTime:f1} seconds to win!";
                Vector2 winMeasures = arial24.MeasureString(win) / 2f;
                Vector2 windowCenter = windowSize / 2f;
                _spriteBatch.DrawString(arial24, win, windowCenter - winMeasures, Color.Black);
            }

            _spriteBatch.DrawString(arial24,
                string.Format("Diamonds: {0}     Dynamites: {1}     Dirt: {2}",
                                Pombo.diamonds, Pombo.dinamites, Pombo.dirt),
                    new Vector2(5, level.GetLength(1) * tileSize ),
                    Color.Black, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0);

            string lifes = string.Format("Time: {0:F0}", levelTime);
            Point measure = arial24.MeasureString(lifes).ToPoint();
            int posX = level.GetLength(0) * tileSize - measure.X - 5;

            _spriteBatch.DrawString(arial24, lifes,
                new Vector2(posX, level.GetLength(1) * tileSize), Color.Black
                , 0f, Vector2.Zero, 1f, SpriteEffects.None, 0);


            _spriteBatch.End();

            base.Draw(gameTime);
        }

        public bool Victory()
        {
            if (level[Pombo.getP().X, Pombo.getP().Y] == 'S')
                return true; return false;
        }

        public char Tile(int x, int y)
        {
            return level[x, y];
        }

        public void destroyTile(int x, int y)
        {
            Point p = new Point(x, y);
            if(x>0&& x < limits.Y && y > 0 && y < limits.X)
            {
                if (level[x, y] == 'D') diamonds.Remove(p);

                if (level[x, y] == 'E') dynamites.Remove(p);

                if (level[x, y] == 'O') stones.Remove(p);

                if (!(level[x, y] == 'X' || level[x, y] == 'S')) level[x, y] = ' ';
            }
        }

        public void gravity()
        {
            for (int i = 0; i < stones.Count; i++)
            {
                if (level[stones[i].X, stones[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(stones[i].X, stones[i].Y + 1)))
                {
                    level[stones[i].X, stones[i].Y] = ' ';
                    level[stones[i].X, stones[i].Y + 1] = 'O';
                    stones[i] = new Point(stones[i].X, stones[i].Y + 1);
                }
                else
                {
                    if (level[stones[i].X, stones[i].Y + 1] == 'O' || level[stones[i].X, stones[i].Y + 1] == 'D')
                    {
                        if (level[stones[i].X - 1, stones[i].Y] == ' ' && !Pombo.pPlayer(new Point(stones[i].X - 1, stones[i].Y)) &&
                            level[stones[i].X - 1, stones[i].Y + 1] == ' ')
                        {
                            level[stones[i].X, stones[i].Y] = ' ';
                            level[stones[i].X - 1, stones[i].Y] = 'O';
                            stones[i] = new Point(stones[i].X - 1, stones[i].Y);
                        }
                        else
                        {
                            if (level[stones[i].X + 1, stones[i].Y] == ' ' && !Pombo.pPlayer(new Point(stones[i].X - 1, stones[i].Y)) &&
                            level[stones[i].X + 1, stones[i].Y + 1] == ' ')
                            {
                                level[stones[i].X, stones[i].Y] = ' ';
                                level[stones[i].X + 1, stones[i].Y] = 'O';
                                stones[i] = new Point(stones[i].X + 1, stones[i].Y);
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < diamonds.Count; i++)
            {
                if (level[diamonds[i].X, diamonds[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X, diamonds[i].Y + 1)))
                {
                    level[diamonds[i].X, diamonds[i].Y] = ' ';
                    level[diamonds[i].X, diamonds[i].Y + 1] = 'D';
                    diamonds[i] = new Point(diamonds[i].X, diamonds[i].Y + 1);
                }
                else
                {
                    if (level[diamonds[i].X, diamonds[i].Y + 1] == 'O' || level[diamonds[i].X, diamonds[i].Y + 1] == 'D')
                    {
                        if (level[diamonds[i].X - 1, diamonds[i].Y] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X - 1, diamonds[i].Y)) &&
                            level[diamonds[i].X - 1, diamonds[i].Y + 1] == ' ')
                        {
                            level[diamonds[i].X, diamonds[i].Y] = ' ';
                            level[diamonds[i].X - 1, diamonds[i].Y] = 'D';
                            diamonds[i] = new Point(diamonds[i].X - 1, diamonds[i].Y);
                        }
                        else
                        {
                            if (level[diamonds[i].X + 1, diamonds[i].Y] == ' ' && !Pombo.pPlayer(new Point(diamonds[i].X - 1, diamonds[i].Y)) &&
                            level[diamonds[i].X + 1, diamonds[i].Y + 1] == ' ')
                            {
                                level[diamonds[i].X, diamonds[i].Y] = ' ';
                                level[diamonds[i].X + 1, diamonds[i].Y] = 'D';
                                diamonds[i] = new Point(diamonds[i].X + 1, diamonds[i].Y);
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < dynamites.Count; i++)
            {
                if (level[dynamites[i].X, dynamites[i].Y + 1] == ' ' && !Pombo.pPlayer(new Point(dynamites[i].X, dynamites[i].Y + 1)))
                {
                    if(level[dynamites[i].X, dynamites[i].Y + 2] == ' ' && !Pombo.pPlayer(new Point(dynamites[i].X, dynamites[i].Y + 1)))
                    {
                        level[dynamites[i].X, dynamites[i].Y] = ' ';
                        level[dynamites[i].X, dynamites[i].Y + 1] = 'E';
                        dynamites[i] = new Point(dynamites[i].X, dynamites[i].Y + 1);
                    }
                    else
                    {
                        level[dynamites[i].X, dynamites[i].Y] = ' ';
                        int x = dynamites[i].X; int y = dynamites[i].Y; 
                        dynamites.Remove(new Point(dynamites[i].X, dynamites[i].Y));
                        BOOOMMM(x, y);
                        
                    }
                }
            }
        }

        public void explusioun()
        {
            if (Pombo.dinamites > 0)
            {
                Point vt = Pombo.getP();
                level[vt.X, vt.Y] = 'F';

                bombas.Add(true);
                bombasP.Add(vt);
                Pombo.dinamites--;
            }
        }

        public void BOOOMMM(int x,int y)
        {
            for(int i = x - ERadious; i <= x + ERadious; i++)
            {
                for(int u = y + ERadious; u >= y - ERadious; u--)
                {
                    destroyTile(i, u);
                }
            }
            Console.WriteLine("CABOOOMMMM!!!!");
        }

       
        void LoadLevel(string levelFile)
        {
            bombas = new List<bool>();
            bombasP = new List<Point>();
            bombasT = new List<double>();

            stones = new List<Point>();
            diamonds = new List<Point>();
            dynamites = new List<Point>();

            string[] linhas = File.ReadAllLines("Content/" + levelFile);
            int nrLinhas = linhas.Length; int nrColunas = linhas[0].Length;
            limits = new Vector2(nrLinhas, nrColunas);

            level = new char[nrColunas, nrLinhas];

            for (int x = 0; x < nrColunas; x++)
            {
                for (int y = 0; y < nrLinhas; y++)
                {
                    switch (linhas[y][x])
                    {
                        case 'Y': Pombo = new Player(this, x, y); level[x, y] = ' '; break;
                        case 'O': stones.Add(new Point(x, y)); level[x, y] = 'O'; break;
                        case 'D': diamonds.Add(new Point(x, y)); level[x, y] = 'D'; break;
                        case 'E': dynamites.Add(new Point(x, y)); level[x, y] = 'E'; break;
                        default: level[x, y] = linhas[y][x]; break;
                    }
                }
            }
        }
    }
}

