﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//https://www.youtube.com/watch?v=lcrgj26G5Hg

namespace pigeonMiner
{
    public abstract class Component
    {
        public abstract void Draw(GameTime gameTime, SpriteBatch spriteBatch);

        public abstract void Update(GameTime gameTime);
    }
}